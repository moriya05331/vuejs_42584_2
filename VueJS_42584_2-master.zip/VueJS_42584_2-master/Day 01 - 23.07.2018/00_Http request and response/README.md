
# HTTP requesr and response
* every request contains head and body
* every response contains head and body

## Basic content of requesr and response
![picture](reqres.png)